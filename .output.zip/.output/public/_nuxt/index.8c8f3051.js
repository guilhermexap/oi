import{G as e,I as n}from"./entry.b2916cb1.js";const _={__name:"index",async setup(s){let t,a;return[t,a]=e(()=>n("/organizations")),await t,a(),()=>{}}};export{_ as default};
