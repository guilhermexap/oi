const s=(t,e)=>!!(e.value&&e.value.find(n=>n.$property===t)),u=(t,e)=>{if(e.value){const r=e.value.find(n=>n.$property===t);return r==null?void 0:r.$message}return null};export{u as g,s as i};
