let u=0;function i(){return`nuid-${u++}`}export{i as u};
