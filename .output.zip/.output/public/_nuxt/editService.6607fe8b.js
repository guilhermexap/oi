import{r as a}from"./entry.b2916cb1.js";const e=a(null);function n(t){e.value=t}function r(){return e.value}export{r as g,n as s};
