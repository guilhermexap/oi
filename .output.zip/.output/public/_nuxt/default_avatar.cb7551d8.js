import"./entry.b2916cb1.js";const t=""+new URL("default_avatar.65b5b751.jpeg",import.meta.url).href;export{t as d};
